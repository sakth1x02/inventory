// Data modeling and helpers
const rawItems = [
  // Bolts & Screws
  {category:"Bolts & Screws", name:"Hex Head Bolt (M8)", specs:"M8 × 40 mm, Grade 8.8", opening:"350,000 pcs", receipts:80000, issues:82000, closing:348000, stockValue:"1.2 Cr", remarks:"Export orders", upc:"123456789101", mpn:"SFL-BOLT-HX-01", ean:"4006381333951", isbn:"9781234567821", price:"₹14 / pc", desc:"High-strength hex bolt for auto chassis & construction assemblies."},
  {category:"Bolts & Screws", name:"Socket Head Cap Screw", specs:"M10 × 50 mm, Alloy Steel", opening:"320,000 pcs", receipts:75000, issues:72000, closing:323000, stockValue:"1.1 Cr", remarks:"Stable", upc:"123456789102", mpn:"SFL-BOLT-SH-02", ean:"4006381333952", isbn:"9781234567822", price:"₹16 / pc", desc:"Alloy steel socket screw for machinery and automotive applications."},
  {category:"Bolts & Screws", name:"Flange Bolt (M10)", specs:"M10 × 60 mm, Zinc Plated", opening:"290,000 pcs", receipts:70000, issues:74000, closing:286000, stockValue:"1.0 Cr", remarks:"Slight dip", upc:"123456789103", mpn:"SFL-BOLT-FL-03", ean:"4006381333953", isbn:"9781234567823", price:"₹12 / pc", desc:"Zinc-plated flange bolt with corrosion resistance for OEM supply."},
  {category:"Bolts & Screws", name:"Machine Screw (M6)", specs:"M6 × 25 mm, SS304", opening:"410,000 pcs", receipts:95000, issues:96000, closing:409000, stockValue:"1.5 Cr", remarks:"Balanced", upc:"123456789104", mpn:"SFL-SCREW-MC-04", ean:"4006381333954", isbn:"9781234567824", price:"₹9 / pc", desc:"Stainless steel screw for electrical panels and appliance fittings."},
  {category:"Bolts & Screws", name:"Self-Tapping Screw", specs:"4.2 × 19 mm, Zinc Plated", opening:"380,000 pcs", receipts:90000, issues:96000, closing:374000, stockValue:"1.3 Cr", remarks:"Domestic demand rising", upc:"123456789105", mpn:"SFL-SCREW-ST-05", ean:"4006381333955", isbn:"9781234567825", price:"₹6 / pc", desc:"Self-drilling screw for sheet metal fabrication & assemblies."},
  // Radiator Caps
  {category:"Radiator Caps", name:"Metal OEM Cap", specs:"90 mm, 1.1 bar, Brass", opening:"25,000 pcs", receipts:6000, issues:5500, closing:25500, stockValue:"12 L", remarks:"Stable demand", upc:"123456789111", mpn:"SFL-RADC-MTL-01", ean:"4006381333961", isbn:"9781234567831", price:"₹95 / pc", desc:"Brass OEM radiator cap designed for standard cooling systems."},
  {category:"Radiator Caps", name:"Metal Lever-Type Cap", specs:"85 mm, 1.2 bar, SS", opening:"18,000 pcs", receipts:4000, issues:3500, closing:18500, stockValue:"10 L", remarks:"Safety stock ok", upc:"123456789112", mpn:"SFL-RADC-MTL-02", ean:"4006381333962", isbn:"9781234567832", price:"₹120 / pc", desc:"Stainless lever-type radiator cap with extra pressure handling."},
  {category:"Radiator Caps", name:"Nylon Ratcheting Cap", specs:"80 mm, 1.0 bar, Nylon", opening:"15,000 pcs", receipts:4500, issues:4000, closing:15500, stockValue:"14 L", remarks:"Growing demand", upc:"123456789113", mpn:"SFL-RADC-NYL-01", ean:"4006381333963", isbn:"9781234567833", price:"₹70 / pc", desc:"Lightweight nylon radiator cap with ratcheting lock system."},
  {category:"Radiator Caps", name:"Dual O-Ring Nylon Cap", specs:"75 mm, 0.9 bar, Nylon", opening:"14,000 pcs", receipts:3500, issues:3000, closing:14500, stockValue:"11 L", remarks:"Stable", upc:"123456789114", mpn:"SFL-RADC-NYL-02", ean:"4006381333964", isbn:"9781234567834", price:"₹85 / pc", desc:"Enhanced sealing radiator cap with dual O-rings for leak prevention."},
  {category:"Radiator Caps", name:"Mini/Micro Radiator Cap", specs:"65 mm, 0.8 bar, Compact", opening:"10,000 pcs", receipts:2000, issues:2000, closing:10000, stockValue:"9 L", remarks:"Balanced", upc:"123456789115", mpn:"SFL-RADC-MIC-01", ean:"4006381333965", isbn:"9781234567835", price:"₹55 / pc", desc:"Compact radiator cap for two-wheelers and small cars."},
  // Powertrain Shafts
  {category:"Powertrain Shafts", name:"Propeller Shaft", specs:"Ø 65 mm × 1200 mm, Forged Steel", opening:"10,000 pcs", receipts:3000, issues:2800, closing:10200, stockValue:"75 L", remarks:"Auto sector demand", upc:"123456789121", mpn:"SFL-SHAFT-PR-01", ean:"4006381333971", isbn:"9781234567841", price:"₹3,200 / pc", desc:"Heavy-duty propeller shaft for trucks and commercial vehicles."},
  {category:"Powertrain Shafts", name:"Differential Shaft", specs:"Ø 55 mm × 900 mm, Heat-Treated", opening:"8,500 pcs", receipts:2500, issues:2200, closing:8800, stockValue:"65 L", remarks:"Exports stable", upc:"123456789122", mpn:"SFL-SHAFT-DF-02", ean:"4006381333972", isbn:"9781234567842", price:"₹2,800 / pc", desc:"Precision differential shaft used in passenger and utility vehicles."},
  {category:"Powertrain Shafts", name:"Transmission Input Shaft", specs:"Ø 50 mm × 700 mm, Alloy Steel", opening:"9,500 pcs", receipts:3200, issues:3000, closing:9700, stockValue:"72 L", remarks:"Safety stock > threshold", upc:"123456789123", mpn:"SFL-SHAFT-IN-03", ean:"4006381333973", isbn:"9781234567843", price:"₹2,600 / pc", desc:"Alloy steel input shaft for manual/automatic transmissions."},
  {category:"Powertrain Shafts", name:"Transmission Output Shaft", specs:"Ø 60 mm × 800 mm, Forged Steel", opening:"11,000 pcs", receipts:3800, issues:3400, closing:11400, stockValue:"82 L", remarks:"Demand up", upc:"123456789124", mpn:"SFL-SHAFT-OT-04", ean:"4006381333974", isbn:"9781234567844", price:"₹2,950 / pc", desc:"Output shaft for high-load gear transmission systems."},
  {category:"Powertrain Shafts", name:"Axle Shaft", specs:"Ø 70 mm × 950 mm, Induction Hardened", opening:"9,000 pcs", receipts:2500, issues:2100, closing:9400, stockValue:"68 L", remarks:"Stable", upc:"123456789125", mpn:"SFL-SHAFT-AX-05", ean:"4006381333975", isbn:"9781234567845", price:"₹3,000 / pc", desc:"Induction-hardened axle shaft for durability in rough terrains."},
  // Pumps & Assemblies
  {category:"Pumps & Assemblies", name:"Oil Pump Assembly", specs:"Ø 80 mm, Flow 45 L/min", opening:"4,000 pcs", receipts:1200, issues:1000, closing:4200, stockValue:"55 L", remarks:"Consistent demand", upc:"123456789131", mpn:"SFL-PUMP-OIL-01", ean:"4006381333981", isbn:"9781234567851", price:"₹1,450 / pc", desc:"Automotive oil pump assembly with consistent flow output."},
  {category:"Pumps & Assemblies", name:"Water Pump Assembly", specs:"Ø 100 mm, Flow 65 L/min", opening:"5,500 pcs", receipts:1600, issues:1500, closing:5600, stockValue:"70 L", remarks:"Stable", upc:"123456789132", mpn:"SFL-PUMP-WTR-02", ean:"4006381333982", isbn:"9781234567852", price:"₹1,700 / pc", desc:"Water pump assembly used in passenger and heavy vehicles."},
  {category:"Pumps & Assemblies", name:"Hydraulic Pump", specs:"Ø 120 mm, 210 bar", opening:"3,200 pcs", receipts:950, issues:900, closing:3250, stockValue:"58 L", remarks:"Industrial demand", upc:"123456789133", mpn:"SFL-PUMP-HYD-03", ean:"4006381333983", isbn:"9781234567853", price:"₹2,800 / pc", desc:"High-pressure hydraulic pump for industrial and automotive hydraulics."},
  {category:"Pumps & Assemblies", name:"Fuel Pump Assembly", specs:"Ø 90 mm, Flow 55 L/min", opening:"4,500 pcs", receipts:1300, issues:1200, closing:4600, stockValue:"64 L", remarks:"Auto OEM orders", upc:"123456789134", mpn:"SFL-PUMP-FUL-04", ean:"4006381333984", isbn:"9781234567854", price:"₹1,600 / pc", desc:"Fuel pump assembly optimized for modern injection systems."},
  {category:"Pumps & Assemblies", name:"Gear Pump Assembly", specs:"Ø 75 mm, Flow 40 L/min", opening:"2,300 pcs", receipts:800, issues:750, closing:2350, stockValue:"46 L", remarks:"Balanced", upc:"123456789135", mpn:"SFL-PUMP-GRP-05", ean:"4006381333985", isbn:"9781234567855", price:"₹1,350 / pc", desc:"Gear-driven pump for industrial and automotive lubrication."},
  // Cold Forged Parts
  {category:"Cold Forged Parts", name:"Cold Forged Bolt (M12)", specs:"M12 × 70 mm, Class 10.9", opening:"14,000 pcs", receipts:4200, issues:4000, closing:14200, stockValue:"45 L", remarks:"Within limit", upc:"123456789141", mpn:"SFL-CFPT-BLT-01", ean:"4006381333991", isbn:"9781234567861", price:"₹20 / pc", desc:"High-strength cold forged bolt for OEM and aftermarket."},
  {category:"Cold Forged Parts", name:"Cold Forged Nut (M10)", specs:"M10, Hex, Class 8", opening:"12,500 pcs", receipts:3800, issues:3600, closing:12700, stockValue:"42 L", remarks:"Stable", upc:"123456789142", mpn:"SFL-CFPT-NUT-02", ean:"4006381333992", isbn:"9781234567862", price:"₹10 / pc", desc:"Cold forged hex nut for automotive and industrial use."},
  {category:"Cold Forged Parts", name:"Cold Forged Pin", specs:"Ø 12 mm × 60 mm", opening:"11,000 pcs", receipts:3200, issues:3000, closing:11200, stockValue:"40 L", remarks:"Balanced", upc:"123456789143", mpn:"SFL-CFPT-PIN-03", ean:"4006381333993", isbn:"9781234567863", price:"₹15 / pc", desc:"Forged steel pin for multiple fastening and alignment applications."},
  {category:"Cold Forged Parts", name:"Cold Forged Flange", specs:"Ø 80 mm, Thickness 10 mm", opening:"13,000 pcs", receipts:3900, issues:3600, closing:13300, stockValue:"43 L", remarks:"Growing demand", upc:"123456789144", mpn:"SFL-CFPT-FLG-04", ean:"4006381333994", isbn:"9781234567864", price:"₹40 / pc", desc:"Cold forged flange part for heavy vehicle assemblies."},
  {category:"Cold Forged Parts", name:"Cold Forged Spacer", specs:"Ø 25 mm × 10 mm, Hardened", opening:"15,000 pcs", receipts:4000, issues:3700, closing:15300, stockValue:"47 L", remarks:"Demand increasing", upc:"123456789145", mpn:"SFL-CFPT-SPC-05", ean:"4006381333995", isbn:"9781234567865", price:"₹25 / pc", desc:"Hardened cold-forged spacer for industrial applications."}
];

function parseIndianMoney(value){
  if(typeof value === "number") return value;
  if(!value) return 0;
  const v = value.toString().replace(/[,₹\s/pc]/g,"");
  if(/cr$/i.test(v)) return parseFloat(v.replace(/cr/i,""))*1e7; // 1 Cr = 1 Crore = 10,000,000
  if(/l$/i.test(v)) return parseFloat(v.replace(/l/i,""))*1e5;   // 1 Lakh = 100,000
  const n = parseFloat(v);
  return isNaN(n)?0:n;
}

function parseQty(value){
  if(typeof value === "number") return value;
  if(!value) return 0;
  return parseInt(value.toString().replace(/[^0-9]/g,""),10) || 0;
}

const items = rawItems.map(it=>({
  ...it,
  openingQty: parseQty(it.opening),
  receiptsQty: parseQty(it.receipts),
  issuesQty: parseQty(it.issues),
  closingQty: parseQty(it.closing),
  stockValueINR: parseIndianMoney(it.stockValue),
  sellingPriceINR: parseIndianMoney(it.price)
}));

// KPIs
function computeKPIs(list){
  const totalSkus = list.length;
  const totalClosing = list.reduce((s,i)=>s+i.closingQty,0);
  const totalReceipts = list.reduce((s,i)=>s+i.receiptsQty,0);
  const totalIssues = list.reduce((s,i)=>s+i.issuesQty,0);
  const totalValue = list.reduce((s,i)=>s+i.stockValueINR,0);
  return {totalSkus,totalClosing,totalReceipts,totalIssues,totalValue};
}

function formatINR(n){
  return new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(n);
}

function formatNumber(n){
  return new Intl.NumberFormat('en-IN').format(n);
}

// Rendering
function renderSummary(){
  const k = computeKPIs(items);
  const host = document.getElementById('summary');
  host.innerHTML = `
    <div class="col-sm-6 col-lg-3"><div class="kpi-card kpi-total"><span class="icon">📦</span><div><div class="small">Total SKUs</div><div class="fs-5 fw-bold">${formatNumber(k.totalSkus)}</div></div></div></div>
    <div class="col-sm-6 col-lg-3"><div class="kpi-card kpi-closing"><span class="icon">🧮</span><div><div class="small">Closing Stock (pcs)</div><div class="fs-5 fw-bold">${formatNumber(k.totalClosing)}</div></div></div></div>
    <div class="col-sm-6 col-lg-3"><div class="kpi-card kpi-receipts"><span class="icon">⬇️</span><div><div class="small">Receipts (pcs)</div><div class="fs-5 fw-bold">${formatNumber(k.totalReceipts)}</div></div></div></div>
    <div class="col-sm-6 col-lg-3"><div class="kpi-card kpi-issues"><span class="icon">⬆️</span><div><div class="small">Issues (pcs)</div><div class="fs-5 fw-bold">${formatNumber(k.totalIssues)}</div></div></div></div>
    <div class="col-12 col-lg-6 mt-2"><div class="kpi-card kpi-value"><span class="icon">💰</span><div><div class="small">Stock Value</div><div class="fs-5 fw-bold">${formatINR(k.totalValue)}</div></div></div></div>
  `;
}

function uniqueCategories(){
  return Array.from(new Set(items.map(i=>i.category)));
}

function renderFilters(){
  const sel = document.getElementById('categoryFilter');
  const cats = uniqueCategories();
  sel.innerHTML = `<option value="">All Categories</option>` + cats.map(c=>`<option>${c}</option>`).join('');
}

function renderTable(){
  const tbody = document.querySelector('#inventoryTable tbody');
  const q = document.getElementById('search').value.toLowerCase();
  const cat = document.getElementById('categoryFilter').value;
  const filtered = items.filter(i => (
    (!cat || i.category===cat) && (
      i.name.toLowerCase().includes(q) || i.category.toLowerCase().includes(q) || i.mpn.toLowerCase().includes(q)
    )
  ));
  tbody.innerHTML = filtered.map(i=>`
    <tr>
      <td>${i.category}</td>
      <td title="${i.desc}">${i.name}</td>
      <td>${i.specs}</td>
      <td class="text-end">${formatNumber(i.openingQty)}</td>
      <td class="text-end text-success">${formatNumber(i.receiptsQty)}</td>
      <td class="text-end text-danger">${formatNumber(i.issuesQty)}</td>
      <td class="text-end fw-semibold">${formatNumber(i.closingQty)}</td>
      <td class="text-end">${formatINR(i.stockValueINR)}</td>
      <td>${i.remarks}</td>
      <td>${i.upc}</td>
      <td>${i.mpn}</td>
      <td>${i.ean}</td>
      <td>${i.isbn}</td>
      <td class="text-end">${i.price}</td>
    </tr>
  `).join('');
}

let charts = {};
function renderCharts(){
  const byCat = uniqueCategories().map(c=>({
    category:c,
    closing: items.filter(i=>i.category===c).reduce((s,i)=>s+i.closingQty,0)
  }));
  const receiptsIssues = uniqueCategories().map(c=>({
    category:c,
    receipts: items.filter(i=>i.category===c).reduce((s,i)=>s+i.receiptsQty,0),
    issues: items.filter(i=>i.category===c).reduce((s,i)=>s+i.issuesQty,0)
  }));

  // Pie/Donut for stock by category
  const ctx1 = document.getElementById('stockByCategory');
  charts.stockByCategory?.destroy();
  charts.stockByCategory = new Chart(ctx1, {
    type:'doughnut',
    data:{
      labels: byCat.map(x=>x.category),
      datasets:[{data: byCat.map(x=>x.closing), backgroundColor:['#0d6efd','#198754','#6f42c1','#20c997','#fd7e14','#6610f2','#6c757d']}]
    },
    options:{plugins:{legend:{position:'bottom'}}, cutout:'60%'}
  });

  // Bar for receipts vs issues
  const ctx2 = document.getElementById('receiptsVsIssues');
  charts.receiptsVsIssues?.destroy();
  charts.receiptsVsIssues = new Chart(ctx2, {
    type:'bar',
    data:{
      labels: receiptsIssues.map(x=>x.category),
      datasets:[
        {label:'Receipts', data: receiptsIssues.map(x=>x.receipts), backgroundColor:'#20c997'},
        {label:'Issues', data: receiptsIssues.map(x=>x.issues), backgroundColor:'#fd7e14'}
      ]
    },
    options:{responsive:true, scales:{y:{beginAtZero:true}}}
  });
}

function init(){
  renderSummary();
  renderFilters();
  renderTable();
  renderCharts();
  document.getElementById('search').addEventListener('input',()=>{renderTable();});
  document.getElementById('categoryFilter').addEventListener('change',()=>{renderTable(); renderCharts();});
}

document.addEventListener('DOMContentLoaded', init);


