# Enterprise Inventory Management Dashboard

A professional, enterprise-grade inventory management dashboard built with React, TailwindCSS, shadcn/ui, lucide-react, and framer-motion.

## Features

- **Single-page design** - All content visible without vertical scrolling
- **Real-time filtering** - Category-based filtering with smooth transitions
- **Comprehensive data** - Complete inventory dataset across 5 categories
- **Professional styling** - Enterprise-grade UI with clean, modern design
- **Responsive layout** - Optimized for desktop viewing
- **Smooth animations** - Framer Motion powered transitions

## Categories

- Bolts & Screws (5 items)
- Radiator Caps (3 items) 
- Powertrain Shafts (3 items)
- Pumps & Assemblies (3 items)
- Cold Forged Parts (3 items)

## Data Fields

Each inventory item includes:
- Item Category & Variation/Type
- Dimensions/Specifications
- Stock movements (Opening, Receipts, Issues, Closing)
- Financial data (Stock Value, Selling Price)
- Product identifiers (UPC, MPN, EAN, ISBN)
- Business context (Remarks, Sales Description)

## Setup Instructions

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start development server:**
   ```bash
   npm run dev
   ```

3. **Build for production:**
   ```bash
   npm run build
   ```

## Technology Stack

- **React 18** - UI framework
- **TypeScript** - Type safety
- **TailwindCSS** - Styling
- **shadcn/ui** - Component library
- **lucide-react** - Icons
- **framer-motion** - Animations
- **Vite** - Build tool

## Design Principles

- **Enterprise-grade** - Professional, robust design
- **Compact layout** - Maximum information density
- **No vertical scrolling** - All content fits on one screen
- **Consistent styling** - Unified design language
- **Smooth interactions** - Polished user experience

## File Structure

```
src/
├── components/ui/          # shadcn/ui components
├── data/                   # Inventory dataset
├── lib/                    # Utility functions
├── App.tsx                 # Main dashboard component
├── main.tsx               # Application entry point
└── index.css              # Global styles
```
