export interface InventoryItem {
  itemCategory: string;
  variationType: string;
  dimensionsSpecs: string;
  openingStock: number;
  receipts: number;
  issues: number;
  closingStock: number;
  stockValueINR: string;
  remarks: string;
  upc: string;
  mpn: string;
  ean: string;
  isbn: string;
  sellingPriceINR: string;
  salesDescription: string;
}

export const inventoryData: InventoryItem[] = [
  // Bolts & Screws
  {
    itemCategory: "Bolts & Screws",
    variationType: "Hex Head Bolt (M8)",
    dimensionsSpecs: "M8 × 40 mm, Grade 8.8",
    openingStock: 350000,
    receipts: 80000,
    issues: 82000,
    closingStock: 348000,
    stockValueINR: "1.2 Cr",
    remarks: "Export orders",
    upc: "123456789101",
    mpn: "SFL-BOLT-HX-01",
    ean: "4006381333951",
    isbn: "9781234567821",
    sellingPriceINR: "₹14 / pc",
    salesDescription: "High-strength hex bolt for auto chassis & construction assemblies"
  },
  {
    itemCategory: "Bolts & Screws",
    variationType: "Socket Head Cap Screw",
    dimensionsSpecs: "M10 × 50 mm, Alloy Steel",
    openingStock: 320000,
    receipts: 75000,
    issues: 72000,
    closingStock: 323000,
    stockValueINR: "1.1 Cr",
    remarks: "Stable",
    upc: "123456789102",
    mpn: "SFL-BOLT-SH-02",
    ean: "4006381333952",
    isbn: "9781234567822",
    sellingPriceINR: "₹16 / pc",
    salesDescription: "Alloy steel socket screw for machinery and automotive applications"
  },
  {
    itemCategory: "Bolts & Screws",
    variationType: "Flange Bolt (M10)",
    dimensionsSpecs: "M10 × 60 mm, Zinc Plated",
    openingStock: 290000,
    receipts: 70000,
    issues: 74000,
    closingStock: 286000,
    stockValueINR: "1.0 Cr",
    remarks: "Slight dip",
    upc: "123456789103",
    mpn: "SFL-BOLT-FL-03",
    ean: "4006381333953",
    isbn: "9781234567823",
    sellingPriceINR: "₹12 / pc",
    salesDescription: "Zinc-plated flange bolt with corrosion resistance for OEM supply"
  },
  {
    itemCategory: "Bolts & Screws",
    variationType: "Machine Screw (M6)",
    dimensionsSpecs: "M6 × 25 mm, SS304",
    openingStock: 410000,
    receipts: 95000,
    issues: 96000,
    closingStock: 409000,
    stockValueINR: "1.5 Cr",
    remarks: "Balanced",
    upc: "123456789104",
    mpn: "SFL-SCREW-MC-04",
    ean: "4006381333954",
    isbn: "9781234567824",
    sellingPriceINR: "₹9 / pc",
    salesDescription: "Stainless steel screw for electrical panels and appliance fittings"
  },
  {
    itemCategory: "Bolts & Screws",
    variationType: "Self-Tapping Screw",
    dimensionsSpecs: "4.2 × 19 mm, Zinc Plated",
    openingStock: 380000,
    receipts: 90000,
    issues: 96000,
    closingStock: 374000,
    stockValueINR: "1.3 Cr",
    remarks: "Domestic demand rising",
    upc: "123456789105",
    mpn: "SFL-SCREW-ST-05",
    ean: "4006381333955",
    isbn: "9781234567825",
    sellingPriceINR: "₹6 / pc",
    salesDescription: "Self-drilling screw for sheet metal fabrication & assemblies"
  },

  // Radiator Caps
  {
    itemCategory: "Radiator Caps",
    variationType: "Metal OEM Cap",
    dimensionsSpecs: "90 mm, 1.1 bar, Brass",
    openingStock: 25000,
    receipts: 6000,
    issues: 5500,
    closingStock: 25500,
    stockValueINR: "12 L",
    remarks: "Stable demand",
    upc: "123456789111",
    mpn: "SFL-RADC-MTL-01",
    ean: "4006381333961",
    isbn: "9781234567831",
    sellingPriceINR: "₹95 / pc",
    salesDescription: "Brass OEM radiator cap designed for standard cooling systems"
  },
  {
    itemCategory: "Radiator Caps",
    variationType: "Plastic Aftermarket Cap",
    dimensionsSpecs: "85 mm, 0.9 bar, Nylon",
    openingStock: 18000,
    receipts: 4500,
    issues: 4200,
    closingStock: 18300,
    stockValueINR: "8 L",
    remarks: "Growing market",
    upc: "123456789112",
    mpn: "SFL-RADC-PLT-02",
    ean: "4006381333962",
    isbn: "9781234567832",
    sellingPriceINR: "₹45 / pc",
    salesDescription: "Nylon radiator cap for aftermarket replacement applications"
  },
  {
    itemCategory: "Radiator Caps",
    variationType: "High Pressure Cap",
    dimensionsSpecs: "95 mm, 1.3 bar, Aluminum",
    openingStock: 12000,
    receipts: 3000,
    issues: 2800,
    closingStock: 12200,
    stockValueINR: "15 L",
    remarks: "Premium segment",
    upc: "123456789113",
    mpn: "SFL-RADC-HP-03",
    ean: "4006381333963",
    isbn: "9781234567833",
    sellingPriceINR: "₹125 / pc",
    salesDescription: "High-pressure aluminum cap for performance cooling systems"
  },

  // Powertrain Shafts
  {
    itemCategory: "Powertrain Shafts",
    variationType: "Drive Shaft Assembly",
    dimensionsSpecs: "850 mm, 32 spline, Hardened Steel",
    openingStock: 850,
    receipts: 200,
    issues: 180,
    closingStock: 870,
    stockValueINR: "2.5 Cr",
    remarks: "Heavy machinery",
    upc: "123456789121",
    mpn: "SFL-SHAFT-DR-01",
    ean: "4006381333971",
    isbn: "9781234567841",
    sellingPriceINR: "₹28,500 / pc",
    salesDescription: "Heavy-duty drive shaft for commercial vehicles and construction equipment"
  },
  {
    itemCategory: "Powertrain Shafts",
    variationType: "Half Shaft (CV Joint)",
    dimensionsSpecs: "420 mm, 28 spline, Alloy Steel",
    openingStock: 1200,
    receipts: 300,
    issues: 280,
    closingStock: 1220,
    stockValueINR: "1.8 Cr",
    remarks: "Passenger vehicles",
    upc: "123456789122",
    mpn: "SFL-SHAFT-HF-02",
    ean: "4006381333972",
    isbn: "9781234567842",
    sellingPriceINR: "₹14,750 / pc",
    salesDescription: "CV joint half shaft for front-wheel drive passenger vehicles"
  },
  {
    itemCategory: "Powertrain Shafts",
    variationType: "Propeller Shaft",
    dimensionsSpecs: "1200 mm, 36 spline, Carbon Steel",
    openingStock: 650,
    receipts: 150,
    issues: 140,
    closingStock: 660,
    stockValueINR: "1.9 Cr",
    remarks: "RWD vehicles",
    upc: "123456789123",
    mpn: "SFL-SHAFT-PR-03",
    ean: "4006381333973",
    isbn: "9781234567843",
    sellingPriceINR: "₹28,800 / pc",
    salesDescription: "Propeller shaft for rear-wheel drive vehicles and light trucks"
  },

  // Pumps & Assemblies
  {
    itemCategory: "Pumps & Assemblies",
    variationType: "Water Pump Assembly",
    dimensionsSpecs: "120 mm impeller, Cast Iron Housing",
    openingStock: 2200,
    receipts: 550,
    issues: 520,
    closingStock: 2230,
    stockValueINR: "1.4 Cr",
    remarks: "Engine cooling",
    upc: "123456789131",
    mpn: "SFL-PUMP-WT-01",
    ean: "4006381333981",
    isbn: "9781234567851",
    sellingPriceINR: "₹6,250 / pc",
    salesDescription: "Engine water pump assembly for automotive cooling systems"
  },
  {
    itemCategory: "Pumps & Assemblies",
    variationType: "Oil Pump (Gear Type)",
    dimensionsSpecs: "80 mm gear, Aluminum Housing",
    openingStock: 1800,
    receipts: 450,
    issues: 430,
    closingStock: 1820,
    stockValueINR: "1.1 Cr",
    remarks: "Engine lubrication",
    upc: "123456789132",
    mpn: "SFL-PUMP-OIL-02",
    ean: "4006381333982",
    isbn: "9781234567852",
    sellingPriceINR: "₹6,100 / pc",
    salesDescription: "Gear-type oil pump for engine lubrication systems"
  },
  {
    itemCategory: "Pumps & Assemblies",
    variationType: "Fuel Pump (Electric)",
    dimensionsSpecs: "12V, 150 LPH, In-tank Type",
    openingStock: 1500,
    receipts: 380,
    issues: 360,
    closingStock: 1520,
    stockValueINR: "95 L",
    remarks: "Fuel delivery",
    upc: "123456789133",
    mpn: "SFL-PUMP-FUEL-03",
    ean: "4006381333983",
    isbn: "9781234567853",
    sellingPriceINR: "₹6,350 / pc",
    salesDescription: "Electric in-tank fuel pump for modern fuel injection systems"
  },

  // Cold Forged Parts
  {
    itemCategory: "Cold Forged Parts",
    variationType: "Wheel Stud (M12)",
    dimensionsSpecs: "M12 × 1.5, 45 mm length, Grade 10.9",
    openingStock: 45000,
    receipts: 12000,
    issues: 11800,
    closingStock: 45200,
    stockValueINR: "85 L",
    remarks: "Wheel mounting",
    upc: "123456789141",
    mpn: "SFL-FORG-STUD-01",
    ean: "4006381333991",
    isbn: "9781234567861",
    sellingPriceINR: "₹19 / pc",
    salesDescription: "High-strength wheel stud for automotive wheel mounting systems"
  },
  {
    itemCategory: "Cold Forged Parts",
    variationType: "Brake Caliper Bolt",
    dimensionsSpecs: "M10 × 1.25, 35 mm, Grade 12.9",
    openingStock: 32000,
    receipts: 8000,
    issues: 7800,
    closingStock: 32200,
    stockValueINR: "65 L",
    remarks: "Brake systems",
    upc: "123456789142",
    mpn: "SFL-FORG-BOLT-02",
    ean: "4006381333992",
    isbn: "9781234567862",
    sellingPriceINR: "₹20 / pc",
    salesDescription: "Ultra-high strength brake caliper mounting bolt"
  },
  {
    itemCategory: "Cold Forged Parts",
    variationType: "Suspension Link Pin",
    dimensionsSpecs: "16 mm × 120 mm, Hardened Steel",
    openingStock: 28000,
    receipts: 7000,
    issues: 6800,
    closingStock: 28200,
    stockValueINR: "1.2 Cr",
    remarks: "Suspension systems",
    upc: "123456789143",
    mpn: "SFL-FORG-PIN-03",
    ean: "4006381333993",
    isbn: "9781234567863",
    sellingPriceINR: "₹425 / pc",
    salesDescription: "Precision-machined suspension link pin for automotive suspension systems"
  }
];

export const categories = [
  "All Categories",
  "Bolts & Screws",
  "Radiator Caps", 
  "Powertrain Shafts",
  "Pumps & Assemblies",
  "Cold Forged Parts"
];
