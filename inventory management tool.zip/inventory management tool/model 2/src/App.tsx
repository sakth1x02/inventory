import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Package, 
  TrendingUp, 
  AlertTriangle, 
  ChevronDown,
  Building2,
  DollarSign,
  Hash,
  Box,
  Plus,
  Edit,
  Trash2,
  Download,
  FileText,
  BarChart3,
  Settings
} from 'lucide-react';
import { Card, CardContent } from './components/ui/card';
import { Button } from './components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './components/ui/dropdown-menu';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import Sidebar from './components/Sidebar';
import InventoryForm from './components/InventoryForm';
import AnalyticsChart, { AnalyticsDatum } from './components/AnalyticsChart';
import { inventoryData, categories, InventoryItem } from './data/inventoryData';
import { downloadPDF } from './utils/pdfGenerator';

function App() {
  const [selectedCategory, setSelectedCategory] = useState("All Categories");
  const [activeTab, setActiveTab] = useState("dashboard");
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>(inventoryData);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [analysisData, setAnalysisData] = useState<AnalyticsDatum[] | null>(null);

  // Load data from localStorage on component mount
  useEffect(() => {
    const savedData = localStorage.getItem('inventoryData');
    if (savedData) {
      setInventoryItems(JSON.parse(savedData));
    }
  }, []);

  // Save data to localStorage whenever inventoryItems changes
  useEffect(() => {
    localStorage.setItem('inventoryData', JSON.stringify(inventoryItems));
  }, [inventoryItems]);

  // Filter data based on selected category
  const filteredData = useMemo(() => {
    if (selectedCategory === "All Categories") {
      return inventoryItems;
    }
    return inventoryItems.filter(item => item.itemCategory === selectedCategory);
  }, [selectedCategory, inventoryItems]);

  // Calculate summary metrics
  const summaryMetrics = useMemo(() => {
    const totalStockValue = filteredData.reduce((sum, item) => {
      const value = parseFloat(item.stockValueINR.replace(/[^\d.]/g, ''));
      const multiplier = item.stockValueINR.includes('Cr') ? 10000000 : 
                        item.stockValueINR.includes('L') ? 100000 : 1;
      return sum + (value * multiplier);
    }, 0);

    const totalItems = filteredData.length;
    const totalClosingStock = filteredData.reduce((sum, item) => sum + item.closingStock, 0);

    return {
      totalStockValue: totalStockValue,
      totalItems,
      totalClosingStock
    };
  }, [filteredData]);

  const formatCurrency = (value: number) => {
    if (value >= 10000000) {
      return `₹${(value / 10000000).toFixed(1)} Cr`;
    } else if (value >= 100000) {
      return `₹${(value / 100000).toFixed(0)} L`;
    } else {
      return `₹${value.toLocaleString()}`;
    }
  };

  // CRUD Operations
  const handleAddItem = () => {
    setEditingItem(null);
    setIsEditing(false);
    setIsFormOpen(true);
  };

  const handleEditItem = (item: InventoryItem) => {
    setEditingItem(item);
    setIsEditing(true);
    setIsFormOpen(true);
  };

  const handleDeleteItem = (mpn: string) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      setInventoryItems(prev => prev.filter(item => item.mpn !== mpn));
    }
  };

  const handleSaveItem = (item: InventoryItem) => {
    if (isEditing && editingItem) {
      // Update existing item
      setInventoryItems(prev => 
        prev.map(existingItem => 
          existingItem.mpn === editingItem.mpn ? item : existingItem
        )
      );
    } else {
      // Add new item
      setInventoryItems(prev => [...prev, item]);
    }
    setIsFormOpen(false);
    setEditingItem(null);
    setIsEditing(false);
  };

  const handleCancelForm = () => {
    setIsFormOpen(false);
    setEditingItem(null);
    setIsEditing(false);
  };

  const handleDownloadReport = () => {
    downloadPDF(filteredData, selectedCategory);
  };

  // Build/Clear analytics
  const buildAnalysis = () => {
    const groups: Record<string, { closing: number; valueCr: number }> = {};
    inventoryItems.forEach((item) => {
      const value = parseFloat(item.stockValueINR.replace(/[^\d.]/g, ''));
      const multiplier = item.stockValueINR.includes('Cr') ? 1 : item.stockValueINR.includes('L') ? 0.01 : 0.00001;
      if (!groups[item.itemCategory]) groups[item.itemCategory] = { closing: 0, valueCr: 0 };
      groups[item.itemCategory].closing += item.closingStock;
      groups[item.itemCategory].valueCr += parseFloat((value * multiplier).toFixed(2));
    });
    const data: AnalyticsDatum[] = Object.entries(groups).map(([name, v]) => ({
      name,
      totalClosingStock: v.closing,
      totalStockValueCr: parseFloat(v.valueCr.toFixed(2))
    }));
    setAnalysisData(data);
  };
  const clearAnalysis = () => setAnalysisData(null);

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />
      
      {/* Main Content */}
      <div className="flex-1 p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            {/* Header */}
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center justify-between bg-white rounded-lg shadow-sm p-4"
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-lg flex items-center justify-center">
                  <Building2 className="w-6 h-6 text-white" />
                </div>
                <h1 className="text-xl font-semibold text-gray-900">Inventory Dashboard</h1>
              </div>
              
              <div className="flex items-center space-x-4">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" className="flex items-center space-x-2">
                      <span>{selectedCategory}</span>
                      <ChevronDown className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    {categories.map((category) => (
                      <DropdownMenuItem
                        key={category}
                        onClick={() => setSelectedCategory(category)}
                        className={selectedCategory === category ? "bg-blue-50" : ""}
                      >
                        {category}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
                
                <Button onClick={handleDownloadReport} className="bg-green-600 hover:bg-green-700">
                  <Download className="w-4 h-4 mr-2" />
                  Download PDF
                </Button>
              </div>
            </motion.div>

            {/* Summary Cards */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="grid grid-cols-3 gap-4"
            >
              <Card className="bg-white shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                      <DollarSign className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <p className="text-xs uppercase text-gray-500 font-medium">Total Stock Value</p>
                      <p className="text-lg font-bold text-gray-900">{formatCurrency(summaryMetrics.totalStockValue)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Hash className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-xs uppercase text-gray-500 font-medium">Total Items</p>
                      <p className="text-lg font-bold text-gray-900">{summaryMetrics.totalItems}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                      <Box className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                      <p className="text-xs uppercase text-gray-500 font-medium">Closing Stock</p>
                      <p className="text-lg font-bold text-gray-900">{summaryMetrics.totalClosingStock.toLocaleString()}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Main Table */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white rounded-lg shadow-sm overflow-hidden"
            >
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="text-left py-2 px-2 text-xs font-semibold text-gray-600 uppercase tracking-wider sticky top-0 bg-gray-50">Item Category</th>
                      <th className="text-left py-2 px-2 text-xs font-semibold text-gray-600 uppercase tracking-wider sticky top-0 bg-gray-50">Variation/Type</th>
                      <th className="text-left py-2 px-2 text-xs font-semibold text-gray-600 uppercase tracking-wider sticky top-0 bg-gray-50">Dimensions/Specs</th>
                      <th className="text-right py-2 px-2 text-xs font-semibold text-gray-600 uppercase tracking-wider sticky top-0 bg-gray-50">Opening Stock</th>
                      <th className="text-right py-2 px-2 text-xs font-semibold text-gray-600 uppercase tracking-wider sticky top-0 bg-gray-50">Receipts</th>
                      <th className="text-right py-2 px-2 text-xs font-semibold text-gray-600 uppercase tracking-wider sticky top-0 bg-gray-50">Issues</th>
                      <th className="text-right py-2 px-2 text-xs font-semibold text-gray-600 uppercase tracking-wider sticky top-0 bg-gray-50">Closing Stock</th>
                      <th className="text-right py-2 px-2 text-xs font-semibold text-gray-600 uppercase tracking-wider sticky top-0 bg-gray-50">Stock Value (INR)</th>
                      <th className="text-left py-2 px-2 text-xs font-semibold text-gray-600 uppercase tracking-wider sticky top-0 bg-gray-50">Remarks</th>
                      <th className="text-left py-2 px-2 text-xs font-semibold text-gray-600 uppercase tracking-wider sticky top-0 bg-gray-50">UPC</th>
                      <th className="text-left py-2 px-2 text-xs font-semibold text-gray-600 uppercase tracking-wider sticky top-0 bg-gray-50">MPN</th>
                      <th className="text-left py-2 px-2 text-xs font-semibold text-gray-600 uppercase tracking-wider sticky top-0 bg-gray-50">EAN</th>
                      <th className="text-left py-2 px-2 text-xs font-semibold text-gray-600 uppercase tracking-wider sticky top-0 bg-gray-50">ISBN</th>
                      <th className="text-right py-2 px-2 text-xs font-semibold text-gray-600 uppercase tracking-wider sticky top-0 bg-gray-50">Selling Price (INR)</th>
                      <th className="text-left py-2 px-2 text-xs font-semibold text-gray-600 uppercase tracking-wider sticky top-0 bg-gray-50">Sales Description</th>
                      <th className="text-center py-2 px-2 text-xs font-semibold text-gray-600 uppercase tracking-wider sticky top-0 bg-gray-50">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    <AnimatePresence>
                      {filteredData.map((item, index) => (
                        <motion.tr
                          key={`${item.itemCategory}-${item.mpn}`}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: 20 }}
                          transition={{ delay: index * 0.02 }}
                          className="hover:bg-gray-50 transition-colors"
                        >
                          <td className="py-1 px-2 text-sm text-gray-900 font-medium">{item.itemCategory}</td>
                          <td className="py-1 px-2 text-sm text-gray-900">{item.variationType}</td>
                          <td className="py-1 px-2 text-sm text-gray-600">{item.dimensionsSpecs}</td>
                          <td className="py-1 px-2 text-sm text-gray-900 text-right">{item.openingStock.toLocaleString()}</td>
                          <td className="py-1 px-2 text-sm text-green-600 text-right font-medium">{item.receipts.toLocaleString()}</td>
                          <td className="py-1 px-2 text-sm text-red-600 text-right font-medium">{item.issues.toLocaleString()}</td>
                          <td className="py-1 px-2 text-sm text-gray-900 text-right font-medium">{item.closingStock.toLocaleString()}</td>
                          <td className="py-1 px-2 text-sm text-gray-900 text-right font-medium">{item.stockValueINR}</td>
                          <td className="py-1 px-2 text-sm text-gray-600">{item.remarks}</td>
                          <td className="py-1 px-2 text-sm text-gray-500 font-mono">{item.upc}</td>
                          <td className="py-1 px-2 text-sm text-gray-500 font-mono">{item.mpn}</td>
                          <td className="py-1 px-2 text-sm text-gray-500 font-mono">{item.ean}</td>
                          <td className="py-1 px-2 text-sm text-gray-500 font-mono">{item.isbn}</td>
                          <td className="py-1 px-2 text-sm text-gray-900 text-right font-medium">{item.sellingPriceINR}</td>
                          <td className="py-1 px-2 text-sm text-gray-600 max-w-xs truncate">{item.salesDescription}</td>
                          <td className="py-1 px-2 text-sm">
                            <div className="flex items-center justify-center space-x-1">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleEditItem(item)}
                                className="h-6 w-6 p-0 hover:bg-blue-100"
                              >
                                <Edit className="w-3 h-3 text-blue-600" />
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleDeleteItem(item.mpn)}
                                className="h-6 w-6 p-0 hover:bg-red-100"
                              >
                                <Trash2 className="w-3 h-3 text-red-600" />
                              </Button>
                            </div>
                          </td>
                        </motion.tr>
                      ))}
                    </AnimatePresence>
                  </tbody>
                </table>
              </div>
            </motion.div>
          </TabsContent>

          {/* Inventory Management Tab */}
          <TabsContent value="inventory" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">Inventory Management</h2>
              <Button onClick={handleAddItem} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Add New Item
              </Button>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm p-6">
              <p className="text-gray-600">Use the "Add New Item" button to create inventory items, or use the edit/delete buttons in the dashboard table to manage existing items.</p>
            </div>
          </TabsContent>

          {/* Add Item Tab */}
          <TabsContent value="add-item" className="space-y-6">
            <InventoryForm
              item={null}
              onSave={handleSaveItem}
              onCancel={handleCancelForm}
              isEditing={false}
            />
          </TabsContent>

          {/* Reports Tab */}
          <TabsContent value="reports" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">Reports & Analytics</h2>
              <Button onClick={handleDownloadReport} className="bg-green-600 hover:bg-green-700">
                <Download className="w-4 h-4 mr-2" />
                Download PDF Report
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-white shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <FileText className="w-8 h-8 text-blue-600" />
                    <h3 className="text-lg font-semibold">Inventory Report</h3>
                  </div>
                  <p className="text-gray-600 mb-4">Generate comprehensive PDF reports of your inventory data.</p>
                  <Button onClick={handleDownloadReport} className="w-full">
                    <Download className="w-4 h-4 mr-2" />
                    Download Report
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-white shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <BarChart3 className="w-8 h-8 text-green-600" />
                    <h3 className="text-lg font-semibold">Analytics</h3>
                  </div>
                  <p className="text-gray-600 mb-4">View detailed analytics and insights about your inventory.</p>
                  <Button variant="outline" className="w-full">
                    <BarChart3 className="w-4 h-4 mr-2" />
                    View Analytics
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Analytics Tab (Pie) */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Analytics</h2>
                <p className="text-sm text-gray-500">Pie chart is empty by default. Click Build Analysis.</p>
              </div>
              <div className="space-x-2">
                <Button variant="outline" onClick={clearAnalysis}>Clear</Button>
                <Button className="bg-blue-600 hover:bg-blue-700" onClick={buildAnalysis}>Build Analysis</Button>
              </div>
            </div>

            <AnalyticsChart data={analysisData} metric="value" />
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900">Settings</h2>
            
            <Card className="bg-white shadow-sm">
              <CardContent className="p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <Settings className="w-8 h-8 text-gray-600" />
                  <h3 className="text-lg font-semibold">System Settings</h3>
                </div>
                <p className="text-gray-600">Configure your inventory management system settings.</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Form Dialog */}
        <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
          <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {isEditing ? 'Edit Inventory Item' : 'Add New Inventory Item'}
              </DialogTitle>
            </DialogHeader>
            <InventoryForm
              item={editingItem}
              onSave={handleSaveItem}
              onCancel={handleCancelForm}
              isEditing={isEditing}
            />
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}

export default App;
