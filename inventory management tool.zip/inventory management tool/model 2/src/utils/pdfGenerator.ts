import jsPDF from 'jspdf';
import { InventoryItem } from '../data/inventoryData';

export const generateInventoryReport = (data: InventoryItem[], category: string = 'All Categories') => {
  const doc = new jsPDF('landscape', 'mm', 'a4');
  
  // Company Header
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('SteelForge Mechanical Solutions', 20, 20);
  
  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  doc.text('Inventory Management Report', 20, 30);
  doc.text(`Category: ${category}`, 20, 35);
  doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 20, 40);
  
  // Summary Section
  const totalItems = data.length;
  const totalStockValue = data.reduce((sum, item) => {
    const value = parseFloat(item.stockValueINR.replace(/[^\d.]/g, ''));
    const multiplier = item.stockValueINR.includes('Cr') ? 10000000 : 
                      item.stockValueINR.includes('L') ? 100000 : 1;
    return sum + (value * multiplier);
  }, 0);
  const totalClosingStock = data.reduce((sum, item) => sum + item.closingStock, 0);
  
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('Summary', 20, 55);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Total Items: ${totalItems}`, 20, 65);
  doc.text(`Total Stock Value: ₹${(totalStockValue / 10000000).toFixed(1)} Cr`, 20, 70);
  doc.text(`Total Closing Stock: ${totalClosingStock.toLocaleString()}`, 20, 75);
  
  // Table Header
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Inventory Details', 20, 90);
  
  // Table
  const tableHeaders = [
    'Category', 'Type', 'Dimensions', 'Opening', 'Receipts', 'Issues', 
    'Closing', 'Value (INR)', 'Price (INR)', 'MPN'
  ];
  
  const colWidths = [25, 30, 35, 15, 15, 15, 15, 20, 20, 25];
  const startY = 100;
  let currentY = startY;
  
  // Header row
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  let x = 20;
  tableHeaders.forEach((header, index) => {
    doc.text(header, x, currentY);
    x += colWidths[index];
  });
  
  currentY += 5;
  
  // Data rows
  doc.setFont('helvetica', 'normal');
  data.forEach((item, index) => {
    if (currentY > 180) {
      doc.addPage();
      currentY = 20;
    }
    
    const rowData = [
      item.itemCategory.substring(0, 12),
      item.variationType.substring(0, 15),
      item.dimensionsSpecs.substring(0, 20),
      item.openingStock.toString(),
      item.receipts.toString(),
      item.issues.toString(),
      item.closingStock.toString(),
      item.stockValueINR,
      item.sellingPriceINR,
      item.mpn.substring(0, 12)
    ];
    
    x = 20;
    rowData.forEach((cell, cellIndex) => {
      doc.text(cell, x, currentY);
      x += colWidths[cellIndex];
    });
    
    currentY += 5;
  });
  
  // Footer
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text(`Page ${i} of ${pageCount}`, 280, 200);
    doc.text('SteelForge Mechanical Solutions - Inventory Report', 20, 200);
  }
  
  return doc;
};

export const downloadPDF = (data: InventoryItem[], category: string = 'All Categories') => {
  const doc = generateInventoryReport(data, category);
  const fileName = `inventory-report-${category.toLowerCase().replace(/\s+/g, '-')}-${new Date().toISOString().split('T')[0]}.pdf`;
  doc.save(fileName);
};
