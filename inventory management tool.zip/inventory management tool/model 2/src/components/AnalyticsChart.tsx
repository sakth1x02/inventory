import React from 'react'
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { Card, CardContent } from './ui/card'

export type AnalyticsDatum = {
  name: string
  totalClosingStock: number
  totalStockValueCr: number
}

const COLORS = ['#2563eb', '#16a34a', '#f59e0b', '#8b5cf6', '#ef4444']

interface AnalyticsChartProps {
  data: AnalyticsDatum[] | null
  metric?: 'closing' | 'value'
}

const AnalyticsChart: React.FC<AnalyticsChartProps> = ({ data, metric = 'value' }) => {
  if (!data || data.length === 0) {
    return (
      <Card className="bg-white shadow-sm">
        <CardContent className="p-10 text-center text-gray-500">
          <p className="text-sm">No analysis generated yet.</p>
          <p className="text-xs mt-1">Use the Build Analysis button to compute category-wise charts.</p>
        </CardContent>
      </Card>
    )
  }

  const pieData = data.map((d) => ({
    name: d.name,
    value: metric === 'value' ? d.totalStockValueCr : d.totalClosingStock,
  }))

  const total = pieData.reduce((s, d) => s + d.value, 0)

  return (
    <Card className="bg-white shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Category-wise {metric === 'value' ? 'Stock Value (Cr)' : 'Closing Stock'} Share</h3>
          <div className="text-sm text-gray-500">Total: {metric === 'value' ? total.toFixed(2) + ' Cr' : total.toLocaleString()}</div>
        </div>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={120} label>
                {pieData.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value: any) => metric === 'value' ? `${Number(value).toFixed(2)} Cr` : value} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}

export default AnalyticsChart
