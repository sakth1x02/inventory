import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Save, RotateCcw } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { InventoryItem } from '../data/inventoryData';

interface InventoryFormProps {
  item?: InventoryItem | null;
  onSave: (item: InventoryItem) => void;
  onCancel: () => void;
  isEditing: boolean;
}

const InventoryForm: React.FC<InventoryFormProps> = ({ item, onSave, onCancel, isEditing }) => {
  const [formData, setFormData] = useState<InventoryItem>(item || {
    itemCategory: '',
    variationType: '',
    dimensionsSpecs: '',
    openingStock: 0,
    receipts: 0,
    issues: 0,
    closingStock: 0,
    stockValueINR: '',
    remarks: '',
    upc: '',
    mpn: '',
    ean: '',
    isbn: '',
    sellingPriceINR: '',
    salesDescription: ''
  });

  const categories = [
    'Bolts & Screws',
    'Radiator Caps',
    'Powertrain Shafts',
    'Pumps & Assemblies',
    'Cold Forged Parts'
  ];

  const handleInputChange = (field: keyof InventoryItem, value: string | number) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  const handleReset = () => {
    setFormData(item || {
      itemCategory: '',
      variationType: '',
      dimensionsSpecs: '',
      openingStock: 0,
      receipts: 0,
      issues: 0,
      closingStock: 0,
      stockValueINR: '',
      remarks: '',
      upc: '',
      mpn: '',
      ean: '',
      isbn: '',
      sellingPriceINR: '',
      salesDescription: ''
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-lg shadow-lg p-6 max-w-4xl mx-auto"
    >
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-900">
          {isEditing ? 'Edit Inventory Item' : 'Add New Inventory Item'}
        </h2>
        <Button variant="ghost" size="icon" onClick={onCancel}>
          <X className="w-5 h-5" />
        </Button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Basic Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-800 border-b pb-2">Basic Information</h3>
            
            <div>
              <Label htmlFor="itemCategory">Item Category</Label>
              <Select value={formData.itemCategory} onValueChange={(value) => handleInputChange('itemCategory', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="variationType">Variation/Type</Label>
              <Input
                id="variationType"
                value={formData.variationType}
                onChange={(e) => handleInputChange('variationType', e.target.value)}
                placeholder="e.g., Hex Head Bolt (M8)"
                required
              />
            </div>

            <div>
              <Label htmlFor="dimensionsSpecs">Dimensions/Specifications</Label>
              <Input
                id="dimensionsSpecs"
                value={formData.dimensionsSpecs}
                onChange={(e) => handleInputChange('dimensionsSpecs', e.target.value)}
                placeholder="e.g., M8 × 40 mm, Grade 8.8"
                required
              />
            </div>

            <div>
              <Label htmlFor="salesDescription">Sales Description</Label>
              <Textarea
                id="salesDescription"
                value={formData.salesDescription}
                onChange={(e) => handleInputChange('salesDescription', e.target.value)}
                placeholder="Detailed product description"
                rows={3}
              />
            </div>
          </div>

          {/* Stock Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-800 border-b pb-2">Stock Information</h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="openingStock">Opening Stock</Label>
                <Input
                  id="openingStock"
                  type="number"
                  value={formData.openingStock}
                  onChange={(e) => handleInputChange('openingStock', parseInt(e.target.value) || 0)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="receipts">Receipts</Label>
                <Input
                  id="receipts"
                  type="number"
                  value={formData.receipts}
                  onChange={(e) => handleInputChange('receipts', parseInt(e.target.value) || 0)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="issues">Issues</Label>
                <Input
                  id="issues"
                  type="number"
                  value={formData.issues}
                  onChange={(e) => handleInputChange('issues', parseInt(e.target.value) || 0)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="closingStock">Closing Stock</Label>
                <Input
                  id="closingStock"
                  type="number"
                  value={formData.closingStock}
                  onChange={(e) => handleInputChange('closingStock', parseInt(e.target.value) || 0)}
                  required
                />
              </div>
            </div>

            <div>
              <Label htmlFor="stockValueINR">Stock Value (INR)</Label>
              <Input
                id="stockValueINR"
                value={formData.stockValueINR}
                onChange={(e) => handleInputChange('stockValueINR', e.target.value)}
                placeholder="e.g., 1.2 Cr, 50 L"
                required
              />
            </div>

            <div>
              <Label htmlFor="sellingPriceINR">Selling Price (INR)</Label>
              <Input
                id="sellingPriceINR"
                value={formData.sellingPriceINR}
                onChange={(e) => handleInputChange('sellingPriceINR', e.target.value)}
                placeholder="e.g., ₹14 / pc"
                required
              />
            </div>
          </div>
        </div>

        {/* Product Identifiers */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-gray-800 border-b pb-2">Product Identifiers</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="upc">UPC</Label>
              <Input
                id="upc"
                value={formData.upc}
                onChange={(e) => handleInputChange('upc', e.target.value)}
                placeholder="Universal Product Code"
                required
              />
            </div>
            <div>
              <Label htmlFor="mpn">MPN</Label>
              <Input
                id="mpn"
                value={formData.mpn}
                onChange={(e) => handleInputChange('mpn', e.target.value)}
                placeholder="Manufacturer Part Number"
                required
              />
            </div>
            <div>
              <Label htmlFor="ean">EAN</Label>
              <Input
                id="ean"
                value={formData.ean}
                onChange={(e) => handleInputChange('ean', e.target.value)}
                placeholder="European Article Number"
                required
              />
            </div>
            <div>
              <Label htmlFor="isbn">ISBN</Label>
              <Input
                id="isbn"
                value={formData.isbn}
                onChange={(e) => handleInputChange('isbn', e.target.value)}
                placeholder="International Standard Book Number"
                required
              />
            </div>
          </div>
        </div>

        {/* Remarks */}
        <div>
          <Label htmlFor="remarks">Remarks</Label>
          <Textarea
            id="remarks"
            value={formData.remarks}
            onChange={(e) => handleInputChange('remarks', e.target.value)}
            placeholder="Additional notes or comments"
            rows={2}
          />
        </div>

        {/* Form Actions */}
        <div className="flex justify-end space-x-4 pt-6 border-t">
          <Button type="button" variant="outline" onClick={handleReset}>
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset
          </Button>
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
            <Save className="w-4 h-4 mr-2" />
            {isEditing ? 'Update Item' : 'Add Item'}
          </Button>
        </div>
      </form>
    </motion.div>
  );
};

export default InventoryForm;
